#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

int validarNumero(const string& entrada) {
    try {
        size_t pos;
        int numero = stoi(entrada, &pos);
        if (pos != entrada.length()) {
            throw invalid_argument("Entrada contiene caracteres no numericos.");
        }
        return numero;
    } catch (const invalid_argument& e) {
        throw runtime_error("Error: La entrada no es un numero valido. " + string(e.what()));
    } catch (const out_of_range& e) {
        throw runtime_error("Error: El numero esta fuera del rango permitido.");
    }
}

int main() {
    string entrada;
    cout << "Ingrese un numero entero: ";
    getline(cin, entrada);

    try {
        int numero = validarNumero(entrada);
        cout << "Numero valido: " << numero << endl;
    } catch (const runtime_error& e) {
        cout << "Excepcion capturada: " << e.what() << endl;
    }

    cout << "Programa finalizado." << endl;
    return 0;
}
