/***********************************************************************
 * Module:  Fraccion.java
 * Author:  USUARIO
 * Purpose: Defines the Class Fraccion
 ***********************************************************************/

import java.util.*;

/** @pdOid cc2a50a6-e47e-4d26-abbf-8a4c480932ba */
public class Fraccion implements IOperacionesFraccion {
   /** @pdOid 07b60d0f-9957-41e7-8fab-ad5fb6cdb544 */
   private float numerador;
   /** @pdOid d7730055-5da5-4d43-9cd4-c0021a051290 */
   private float denominador;
   
   /** @param n
    * @pdOid a95b2340-5947-4200-92c9-d1625fd185fb */
   public void setNumerador(float n) {
      // TODO: implement
   }
   
   /** @param d
    * @pdOid db952bc9-783d-4bc5-81c8-84dbc6bf70e8 */
   public void setDenominador(float d) {
      // TODO: implement
   }
   
   /** @pdOid f4146da4-d9fb-4d3b-9f34-beb49b2f7e26 */
   public float getNumerador() {
      // TODO: implement
      return 0;
   }
   
   /** @pdOid 5ad15092-1a06-4193-807a-0552b7577e1c */
   public float getDenominador() {
      // TODO: implement
      return 0;
   }
   
   /** @param n 
    * @param d
    * @pdOid 9a5523c0-bdbc-4c7e-9069-7d59c13b2583 */
   public Fraccion(float n, float d) {
      // TODO: implement
   }
   
   /** @param f1 
    * @param f2
    * @pdOid 45e66fcc-fadd-4915-b790-32940d8059ac */
   public Fraccion multiplicar(Fraccion f1, Fraccion f2) {
      // TODO: implement
      return null;
   }

}