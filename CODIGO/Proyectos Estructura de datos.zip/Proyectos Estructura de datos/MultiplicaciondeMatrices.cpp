#include <iostream>

// Clase plantilla para Matriz con memoria dinámica usando array plano
template <typename T>
class Matriz {
private:
    T* datos;
    int filas, columnas;

public:
    // Constructor: inicializa la matriz a cero
    Matriz(int f, int c) : filas(f), columnas(c) {
        datos = new T[filas * columnas];
        for (int i = 0; i < filas * columnas; ++i) {
            datos[i] = T(0); // Inicializar a cero
        }
    }

    // Destructor
    ~Matriz() {
        delete[] datos;
    }

    // Constructor de copia
    Matriz(const Matriz& otra) : filas(otra.filas), columnas(otra.columnas) {
        datos = new T[filas * columnas];
        for (int i = 0; i < filas * columnas; ++i) {
            datos[i] = otra.datos[i];
        }
    }

    // Operador de asignación
    Matriz& operator=(const Matriz& otra) {
        if (this != &otra) {
            // Liberar memoria existente
            delete[] datos;

            // Asignar nueva memoria
            filas = otra.filas;
            columnas = otra.columnas;
            datos = new T[filas * columnas];
            for (int i = 0; i < filas * columnas; ++i) {
                datos[i] = otra.datos[i];
            }
        }
        return *this;
    }

    // Operador * sobrecargado para multiplicación de matrices
    Matriz operator*(const Matriz& otra) const {
        if (columnas != otra.filas) {
            throw std::invalid_argument("El numero de columnas de la primera matriz debe ser igual al numero de filas de la segunda matriz para la multiplicacion");
        }
        Matriz resultado(filas, otra.columnas);
        for (int i = 0; i < filas; ++i) {
            for (int j = 0; j < otra.columnas; ++j) {
                for (int k = 0; k < columnas; ++k) {
                    resultado.datos[i * otra.columnas + j] += datos[i * columnas + k] * otra.datos[k * otra.columnas + j];
                }
            }
        }
        return resultado;
    }

    // Función para establecer un valor (sobrecarga de función para establecer)
    void establecerValor(int f, int c, T val) {
        if (f >= 0 && f < filas && c >= 0 && c < columnas) {
            datos[f * columnas + c] = val;
        }
    }

    // Función para obtener un valor (sobrecarga de función para obtener)
    T obtenerValor(int f, int c) const {
        if (f >= 0 && f < filas && c >= 0 && c < columnas) {
            return datos[f * columnas + c];
        }
        return T(0);
    }

    // Operador << sobrecargado para salida
    friend std::ostream& operator<<(std::ostream& os, const Matriz& mat) {
        for (int i = 0; i < mat.filas; ++i) {
            for (int j = 0; j < mat.columnas; ++j) {
                os << mat.datos[i * mat.columnas + j] << " ";
            }
            os << std::endl;
        }
        return os;
    }
};

// Función sobrecargada para multiplicar matrices (alternativa al operador*)
template <typename T>
Matriz<T> multiplicarMatrices(const Matriz<T>& m1, const Matriz<T>& m2) {
    return m1 * m2;
}

// Función sobrecargada para multiplicar matrices usando punteros
template <typename T>
Matriz<T>* multiplicarMatrices(Matriz<T>* m1, Matriz<T>* m2) {
    if (m1 == nullptr || m2 == nullptr) {
        return nullptr;
    }
    return new Matriz<T>(*m1 * *m2);
}

int main() {
    // Crear dos matrices de tamaño 2x2, inicializadas a cero
    Matriz<int> mat1(2, 2);
    Matriz<int> mat2(2, 2);

    // Establecer algunos valores en mat1
    mat1.establecerValor(0, 0, 1);
    mat1.establecerValor(0, 1, 2);
    mat1.establecerValor(1, 0, 3);
    mat1.establecerValor(1, 1, 4);

    // Establecer algunos valores en mat2
    mat2.establecerValor(0, 0, 5);
    mat2.establecerValor(0, 1, 6);
    mat2.establecerValor(1, 0, 7);
    mat2.establecerValor(1, 1, 8);

    std::cout << "Matriz 1:" << std::endl;
    std::cout << mat1 << std::endl;

    std::cout << "Matriz 2:" << std::endl;
    std::cout << mat2 << std::endl;

    // Multiplicación usando operador sobrecargado *
    Matriz<int> producto = mat1 * mat2;

    std::cout << "Multiplicacion usando operador *:" << std::endl;
    std::cout << producto << std::endl;

    // Multiplicación usando función sobrecargada
    Matriz<int> producto2 = multiplicarMatrices(mat1, mat2);

    std::cout << "Multiplicacion usando funcion:" << std::endl;
    std::cout << producto2 << std::endl;

    // Multiplicación usando punteros
    Matriz<int>* ptrMat1 = &mat1;
    Matriz<int>* ptrMat2 = &mat2;
    Matriz<int>* productoPtr = multiplicarMatrices(ptrMat1, ptrMat2);

    if (productoPtr != nullptr) {
        std::cout << "Multiplicacion usando punteros:" << std::endl;
        std::cout << *productoPtr << std::endl;
        delete productoPtr; // Liberar memoria
    }

    return 0;
}
