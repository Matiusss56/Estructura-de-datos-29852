#include <iostream>

// Función 1
double suma1(float a, int b, double c) {
    return a + b + c;
}

// Función 2
double suma2(int a, double b, float c) {
    return a + b + c;
}

// Función 3
double suma3(double a, float b, int c) {
    return a + b + c;
}

// Función 4
double suma4(float a, double b, int c) {
    return a + b + c;
}

// Función 5
double suma5(int a, float b, double c) {
    return a + b + c;
}

int main() {
    float num1;
    int num2;
    double num3;
    std::cout << "Ingrese tres numeros: ";
    std::cin >> num1 >> num2 >> num3;

    
    double resultado1 = suma1(num1, num2, num3);
    std::cout << "Suma 1 (float, int, double): " << resultado1 << std::endl;

    
    double resultado2 = suma2(num2, num3, num1);
    std::cout << "Suma 2 (int, double, float): " << resultado2 << std::endl;


    double resultado3 = suma3(num3, num1, num2);
    std::cout << "Suma 3 (double, float, int): " << resultado3 << std::endl;

    
    double resultado4 = suma4(num1, num3, num2);
    std::cout << "Suma 4 (float, double, int): " << resultado4 << std::endl;

    
    double resultado5 = suma5(num2, num1, num3);
    std::cout << "Suma 5 (int, float, double): " << resultado5 << std::endl;

    return 0;
}
