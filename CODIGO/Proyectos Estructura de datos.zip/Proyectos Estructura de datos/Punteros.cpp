
#include <stdio.h>
int main() {
    int numero = 10;          // Variable normal
    int *ptr = &numero;       // Puntero simple -> guarda la dirección de 'numero'
    int **dptr = &ptr;        // Doble puntero -> guarda la dirección del puntero 'ptr'

    printf("Valor inicial de numero: %d\n", numero);
    printf("Direccion de numero (&numero): %p\n", &numero);
    printf("Contenido de ptr (direccion que apunta): %p\n", ptr);
    printf("Contenido de dptr (direccion que apunta): %p\n\n", dptr);

    // Cambiar valor mediante el puntero simple
    *ptr = 20; // Modifica directamente la variable 'numero'
    printf("Valor de numero cambiado desde *ptr: %d\n", numero);

    // Cambiar valor mediante el doble puntero
    **dptr = 30; // Modifica también la variable 'numero' pero a través de dos niveles
    printf("Valor de numero cambiado desde **dptr: %d\n\n", numero);

    // Mostrar cómo cada nivel apunta al otro
    printf("ptr apunta a: %p (direccion de numero)\n", ptr);
    printf("*ptr es: %d (valor de numero)\n", *ptr);
    printf("dptr apunta a: %p (direccion de ptr)\n", dptr);
    printf("*dptr es: %p (contenido de ptr)\n", *dptr);
    printf("**dptr es: %d (valor de numero)\n", **dptr);

    return 0;
}