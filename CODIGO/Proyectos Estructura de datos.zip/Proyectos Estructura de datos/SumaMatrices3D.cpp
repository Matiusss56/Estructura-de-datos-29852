#include <iostream>

// Clase plantilla para Matriz3D con memoria dinámica usando array plano
template <typename T>
class Matriz3D {
private:
    T* datos;
    int filas, columnas, profundidad;

public:
    // Constructor: inicializa la matriz a cero
    Matriz3D(int f, int c, int p) : filas(f), columnas(c), profundidad(p) {
        datos = new T[filas * columnas * profundidad];
        for (int i = 0; i < filas * columnas * profundidad; ++i) {
            datos[i] = T(0); // Inicializar a cero
        }
    }

    // Destructor
    ~Matriz3D() {
        delete[] datos;
    }

    // Constructor de copia
    Matriz3D(const Matriz3D& otra) : filas(otra.filas), columnas(otra.columnas), profundidad(otra.profundidad) {
        datos = new T[filas * columnas * profundidad];
        for (int i = 0; i < filas * columnas * profundidad; ++i) {
            datos[i] = otra.datos[i];
        }
    }

    // Operador de asignación
    Matriz3D& operator=(const Matriz3D& otra) {
        if (this != &otra) {
            // Liberar memoria existente
            delete[] datos;

            // Asignar nueva memoria
            filas = otra.filas;
            columnas = otra.columnas;
            profundidad = otra.profundidad;
            datos = new T[filas * columnas * profundidad];
            for (int i = 0; i < filas * columnas * profundidad; ++i) {
                datos[i] = otra.datos[i];
            }
        }
        return *this;
    }

    // Función para encerar (poner a cero todos los elementos)
    void encerar() {
        for (int i = 0; i < filas * columnas * profundidad; ++i) {
            datos[i] = T(0);
        }
    }

    // Operador + sobrecargado para suma de matrices 3D
    Matriz3D operator+(const Matriz3D& otra) const {
        if (filas != otra.filas || columnas != otra.columnas || profundidad != otra.profundidad) {
            throw std::invalid_argument("Las matrices 3D deben tener las mismas dimensiones para la suma");
        }
        Matriz3D resultado(filas, columnas, profundidad);
        for (int i = 0; i < filas * columnas * profundidad; ++i) {
            resultado.datos[i] = datos[i] + otra.datos[i];
        }
        return resultado;
    }

    // Función para establecer un valor
    void establecerValor(int f, int c, int p, T val) {
        if (f >= 0 && f < filas && c >= 0 && c < columnas && p >= 0 && p < profundidad) {
            datos[f * columnas * profundidad + c * profundidad + p] = val;
        }
    }

    // Función para obtener un valor
    T obtenerValor(int f, int c, int p) const {
        if (f >= 0 && f < filas && c >= 0 && c < columnas && p >= 0 && p < profundidad) {
            return datos[f * columnas * profundidad + c * profundidad + p];
        }
        return T(0);
    }

    // Operador << sobrecargado para salida
    friend std::ostream& operator<<(std::ostream& os, const Matriz3D& mat) {
        for (int i = 0; i < mat.filas; ++i) {
            for (int j = 0; j < mat.columnas; ++j) {
                for (int k = 0; k < mat.profundidad; ++k) {
                    os << mat.datos[i * mat.columnas * mat.profundidad + j * mat.profundidad + k] << " ";
                }
                os << "| ";
            }
            os << std::endl;
        }
        return os;
    }
};

// Función sobrecargada para sumar matrices 3D (alternativa al operador+)
template <typename T>
Matriz3D<T> sumarMatrices(const Matriz3D<T>& m1, const Matriz3D<T>& m2) {
    return m1 + m2;
}

// Función sobrecargada para sumar matrices 3D usando punteros
template <typename T>
Matriz3D<T>* sumarMatrices(Matriz3D<T>* m1, Matriz3D<T>* m2) {
    if (m1 == nullptr || m2 == nullptr) {
        return nullptr;
    }
    return new Matriz3D<T>(*m1 + *m2);
}

int main() {
    // Crear dos matrices 3D de tamaño 2x2x2, inicializadas a cero
    Matriz3D<int> mat1(2, 2, 2);
    Matriz3D<int> mat2(2, 2, 2);

    // Establecer algunos valores en mat1
    mat1.establecerValor(0, 0, 0, 1);
    mat1.establecerValor(0, 0, 1, 2);
    mat1.establecerValor(0, 1, 0, 3);
    mat1.establecerValor(0, 1, 1, 4);
    mat1.establecerValor(1, 0, 0, 5);
    mat1.establecerValor(1, 0, 1, 6);
    mat1.establecerValor(1, 1, 0, 7);
    mat1.establecerValor(1, 1, 1, 8);

    // Establecer algunos valores en mat2
    mat2.establecerValor(0, 0, 0, 9);
    mat2.establecerValor(0, 0, 1, 10);
    mat2.establecerValor(0, 1, 0, 11);
    mat2.establecerValor(0, 1, 1, 12);
    mat2.establecerValor(1, 0, 0, 13);
    mat2.establecerValor(1, 0, 1, 14);
    mat2.establecerValor(1, 1, 0, 15);
    mat2.establecerValor(1, 1, 1, 16);

    std::cout << "Matriz 3D 1:" << std::endl;
    std::cout << mat1 << std::endl;

    std::cout << "Matriz 3D 2:" << std::endl;
    std::cout << mat2 << std::endl;

    // Suma usando operador sobrecargado +
    Matriz3D<int> suma = mat1 + mat2;

    std::cout << "Suma usando operador +:" << std::endl;
    std::cout << suma << std::endl;

    // Suma usando función sobrecargada
    Matriz3D<int> suma2 = sumarMatrices(mat1, mat2);

    std::cout << "Suma usando función:" << std::endl;
    std::cout << suma2 << std::endl;

    // Suma usando punteros
    Matriz3D<int>* ptrMat1 = &mat1;
    Matriz3D<int>* ptrMat2 = &mat2;
    Matriz3D<int>* sumaPtr = sumarMatrices(ptrMat1, ptrMat2);

    if (sumaPtr != nullptr) {
        std::cout << "Suma usando punteros:" << std::endl;
        std::cout << *sumaPtr << std::endl;
        delete sumaPtr; // Liberar memoria
    }

    // Demostrar encerar
    std::cout << "Encerando mat1..." << std::endl;
    mat1.encerar();
    std::cout << "Matriz 3D 1 después de encerar:" << std::endl;
    std::cout << mat1 << std::endl;

    return 0;
}
