/***********************************************************************
 * Module:  Fraccion.cpp
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 20:35:06
 * Purpose: Implementation of the class Fraccion
 ***********************************************************************/

#include "Fraccion.h"

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::Fraccion(float numerador, float denominador)
// Purpose:    Implementation of Fraccion::Fraccion()
// Parameters:
// - numerador
// - denominador
// Return:     
////////////////////////////////////////////////////////////////////////

Fraccion::Fraccion(float numerador, float denominador)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::getDenominador()
// Purpose:    Implementation of Fraccion::getDenominador()
// Return:     float
////////////////////////////////////////////////////////////////////////

float Fraccion::getDenominador(void)
{
   return denominador;
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::setDenominador(float newDenominador)
// Purpose:    Implementation of Fraccion::setDenominador()
// Parameters:
// - newDenominador
// Return:     void
////////////////////////////////////////////////////////////////////////

void Fraccion::setDenominador(float newDenominador)
{
   denominador = newDenominador;
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::getNumerador()
// Purpose:    Implementation of Fraccion::getNumerador()
// Return:     float
////////////////////////////////////////////////////////////////////////

float Fraccion::getNumerador(void)
{
   return numerador;
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::setNumerador(float newNumerador)
// Purpose:    Implementation of Fraccion::setNumerador()
// Parameters:
// - newNumerador
// Return:     void
////////////////////////////////////////////////////////////////////////

void Fraccion::setNumerador(float newNumerador)
{
   numerador = newNumerador;
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::suma(Fraccion n, Fraccion d)
// Purpose:    Implementation of Fraccion::suma()
// Parameters:
// - n
// - d
// Return:     Fraccion
////////////////////////////////////////////////////////////////////////

Fraccion Fraccion::suma(Fraccion n, Fraccion d)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::resta(Fraccion n, Fraccion d)
// Purpose:    Implementation of Fraccion::resta()
// Parameters:
// - n
// - d
// Return:     Fraccion
////////////////////////////////////////////////////////////////////////

Fraccion Fraccion::resta(Fraccion n, Fraccion d)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::multiplicacion(Fraccion n, Fraccion d)
// Purpose:    Implementation of Fraccion::multiplicacion()
// Parameters:
// - n
// - d
// Return:     Fraccion
////////////////////////////////////////////////////////////////////////

Fraccion Fraccion::multiplicacion(Fraccion n, Fraccion d)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Fraccion::division(Fraccion n, Fraccion d)
// Purpose:    Implementation of Fraccion::division()
// Parameters:
// - n
// - d
// Return:     Fraccion
////////////////////////////////////////////////////////////////////////

Fraccion Fraccion::division(Fraccion n, Fraccion d)
{
   // TODO : implement
}