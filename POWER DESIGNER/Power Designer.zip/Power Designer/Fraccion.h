/***********************************************************************
 * Module:  Fraccion.h
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 20:35:06
 * Purpose: Declaration of the class Fraccion
 ***********************************************************************/

#if !defined(__Class_Diagram_2_Fraccion_h)
#define __Class_Diagram_2_Fraccion_h

#include <IOperacionesFunciones.h>

class Fraccion : public IOperacionesFunciones
{
public:
   Fraccion(float numerador, float denominador);
   float getDenominador(void);
   void setDenominador(float newDenominador);
   float getNumerador(void);
   void setNumerador(float newNumerador);
   Fraccion suma(Fraccion n, Fraccion d);
   Fraccion resta(Fraccion n, Fraccion d);
   Fraccion multiplicacion(Fraccion n, Fraccion d);
   Fraccion division(Fraccion n, Fraccion d);

protected:
private:
   float numerador;
   float denominador;


};

#endif