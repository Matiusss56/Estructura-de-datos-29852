/***********************************************************************
 * Module:  Fraccion.java
 * Author:  USUARIO
 * Purpose: Defines the Class Fraccion
 ***********************************************************************/

/** @pdOid cc2a50a6-e47e-4d26-abbf-8a4c480932ba */
public class Fraccion implements IOperacionesFraccion {
   /** @pdOid 07b60d0f-9957-41e7-8fab-ad5fb6cdb544 */
   private float numerador;
   /** @pdOid d7730055-5da5-4d43-9cd4-c0021a051290 */
   private float denominador;
   
   /** @param n
    * @pdOid a95b2340-5947-4200-92c9-d1625fd185fb */
   public void setNumerador(float n) {
      this.numerador = n;
   }

   /** @param d
    * @pdOid db952bc9-783d-4bc5-81c8-84dbc6bf70e8 */
   public void setDenominador(float d) {
      this.denominador = d;
   }

   /** @pdOid f4146da4-d9fb-4d3b-9f34-beb49b2f7e26 */
   public float getNumerador() {
      return this.numerador;
   }

   /** @pdOid 5ad15092-1a06-4193-807a-0552b7577e1c */
   public float getDenominador() {
      return this.denominador;
   }

   /** @param n
    * @param d
    * @pdOid 9a5523c0-bdbc-4c7e-9069-7d59c13b2583 */
   public Fraccion(float n, float d) {
      this.numerador = n;
      this.denominador = d;
   }

   /** @param f1
    * @param f2
    * @pdOid 45e66fcc-fadd-4915-b790-32940d8059ac */
   @Override
   public Fraccion multiplicar(Fraccion f1, Fraccion f2) {
      float nuevoNumerador = f1.getNumerador() * f2.getNumerador();
      float nuevoDenominador = f1.getDenominador() * f2.getDenominador();
      return new Fraccion(nuevoNumerador, nuevoDenominador);
   }

}