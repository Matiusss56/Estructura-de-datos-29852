/***********************************************************************
 * Module:  IOperacionesFraccion.java
 * Author:  USUARIO
 * Purpose: Defines the Interface IOperacionesFraccion
 ***********************************************************************/


/** @pdOid 844fc30f-e321-4dc6-ac76-49dc4b085e24 */
public interface IOperacionesFraccion {
   /** @param f1 
    * @param f2
    * @pdOid 05575a10-b00a-4b10-b385-7560b408e5a9 */
   Fraccion multiplicar(Fraccion f1, Fraccion f2);

}