/***********************************************************************
 * Module:  IOperacionesFunciones.h
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 20:31:26
 * Purpose: Declaration of the class IOperacionesFunciones
 ***********************************************************************/

#if !defined(__Class_Diagram_2_IOperacionesFunciones_h)
#define __Class_Diagram_2_IOperacionesFunciones_h

#include <Fraccion.h>

class IOperacionesFunciones
{
public:
   virtual Fraccion suma(Fraccion n, Fraccion d)=0;
   virtual Fraccion resta(Fraccion n, Fraccion d)=0;
   virtual Fraccion multiplicacion(Fraccion n, Fraccion d)=0;
   virtual Fraccion division(Fraccion n, Fraccion d)=0;

protected:
private:

};

#endif