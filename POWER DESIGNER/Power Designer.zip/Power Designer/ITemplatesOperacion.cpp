/***********************************************************************
 * Module:  ITemplatesOperacion.h
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 21:18:20
 * Purpose: Declaration of the class ITemplatesOperacion
 ***********************************************************************/

#if !defined(__Class_Diagram_3_ITemplatesOperacion_h)
#define __Class_Diagram_3_ITemplatesOperacion_h

class ITemplatesOperacion
{
public:
   virtual Fraccion<T> multiplicar(T n, T d)=0;

protected:
private:

};

#endif