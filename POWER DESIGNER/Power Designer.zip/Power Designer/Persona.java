/***********************************************************************
 * Module:  Persona.java
 * Author:  matia_myo4ct1
 * Purpose: Defines the Class Persona
 ***********************************************************************/

import java.util.*;

/** @pdOid 22f6a8e1-7b27-4494-9fce-a8218d9b6345 */
public class Persona {
   /** @pdOid 3ac39cb2-b697-43cf-9c5e-d1c96f11d8b5 */
   private int nombre;
   /** @pdOid 1cdc186f-9774-48ac-944d-7542d5fbd366 */
   private int telefono;

}