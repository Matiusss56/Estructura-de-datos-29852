/***********************************************************************
 * Module:  Templates_Fraccion.cpp
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 21:16:59
 * Purpose: Implementation of the class Templates_Fraccion
 ***********************************************************************/

#include "Templates_Fraccion.h"

////////////////////////////////////////////////////////////////////////
// Name:       Templates_Fraccion::Templates_Fraccion(T numerador, T denominador)
// Purpose:    Implementation of Templates_Fraccion::Templates_Fraccion()
// Parameters:
// - numerador
// - denominador
// Return:     
////////////////////////////////////////////////////////////////////////

Templates_Fraccion::Templates_Fraccion(T numerador, T denominador)
{
   // TODO : implement
}

////////////////////////////////////////////////////////////////////////
// Name:       Templates_Fraccion::multiplicar(T n, T d)
// Purpose:    Implementation of Templates_Fraccion::multiplicar()
// Parameters:
// - n
// - d
// Return:     Fraccion<T>
////////////////////////////////////////////////////////////////////////

Fraccion<T> Templates_Fraccion::multiplicar(T n, T d)
{
   // TODO : implement
}