/***********************************************************************
 * Module:  Templates_Fraccion.h
 * Author:  USUARIO
 * Modified: martes, 14 de octubre de 2025 21:16:59
 * Purpose: Declaration of the class Templates_Fraccion
 ***********************************************************************/

#if !defined(__Class_Diagram_3_Templates_Fraccion_h)
#define __Class_Diagram_3_Templates_Fraccion_h

#include <ITemplatesOperacion.h>

class Templates_Fraccion : public ITemplatesOperacion
{
public:
   Templates_Fraccion(T numerador, T denominador);
   Fraccion<T> multiplicar(T n, T d);

protected:
private:
   T numerador;
   T denominador;


};

#endif